//effortless page not found page
function NotFound() {
  return (
    <div>
      <h3>Error 404. Page not found :</h3>
    </div>
  );
}

export default NotFound;
