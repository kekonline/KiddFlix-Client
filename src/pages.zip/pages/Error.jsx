//simple and effortless error page
function Error() {
  return <div>Error</div>;
}

export default Error;
